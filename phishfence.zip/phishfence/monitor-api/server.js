import express from 'express';
import cors from 'cors';
import http from 'http';
import { Server } from 'socket.io';
import { v4 as uuidv4 } from 'uuid';
import path from 'path';
import { fileURLToPath } from 'url';
import bodyParser from 'body-parser';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(__dirname)); // serve bait.png

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

let detections = []; // in-memory; replace with DB in prod
let blacklist = [];

app.get('/bait.png', (req, res) => {
  // Create detection record
  const detection = {
    id: uuidv4(),
    referer: req.get('referer') || req.get('origin') || 'unknown',
    hostHeader: req.get('host') || 'unknown',
    ip: req.ip,
    ua: req.get('user-agent') || '',
    time: new Date().toISOString()
  };
  detections.unshift(detection); // newest first
  io.emit('new-detection', detection);

  // Serve the bait image file
  res.sendFile(path.join(__dirname, 'bait.png'));
});

// Optional POST telemetry (redundant logging from the library)
app.post('/telemetry', (req, res) => {
  const payload = req.body || {};
  const detection = {
    id: uuidv4(),
    referer: payload.referer || req.get('referer') || 'unknown',
    domainClaim: payload.domain || 'unknown',
    ip: req.ip,
    ua: req.get('user-agent') || '',
    time: new Date().toISOString(),
    extra: payload
  };
  detections.unshift(detection);
  io.emit('new-detection', detection);
  res.json({ ok: true });
});

app.get('/detections', (req, res) => {
  res.json(detections.slice(0, 200)); // limit
});

app.get('/blacklist.json', (req, res) => {
  res.json(blacklist);
});

app.post('/blacklist', (req, res) => {
  const domain = req.body?.domain;
  if (!domain) return res.status(400).json({ error: 'domain required' });
  if (!blacklist.includes(domain)) blacklist.push(domain);
  io.emit('blacklist-updated', blacklist);
  res.json({ ok: true, blacklist });
});

// small ping route
app.get('/health', (req, res) => res.json({ ok: true }));

const PORT = process.env.PORT || 5000;
server.listen(PORT, () => console.log(`Monitor API running on port ${PORT}`));