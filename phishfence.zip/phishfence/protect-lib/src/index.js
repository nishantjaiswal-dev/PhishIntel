// protect-lib: upgraded multi-stage protection
(function () {
  // CONFIG: change these for production
  const OFFICIAL_DOMAINS = ["demo.local", "localhost", "127.0.0.1"];
  const MONITOR_API = (typeof PROTECT_MONITOR_URL !== 'undefined') ? PROTECT_MONITOR_URL : "http://localhost:5000";
  const LIB_KEY = "pf-" + (btoa(window.location.origin || window.location.hostname || "unknown")).replace(/=/g, "");

  // Utility: overlay blocking UI
  function showBlockOverlay(msg) {
    try {
      if (document.getElementById('__pf_overlay')) return;
      const ov = document.createElement('div');
      ov.id = '__pf_overlay';
      Object.assign(ov.style, {
        position: 'fixed', inset: '0', background: 'rgba(0,0,0,0.92)',
        color: '#fff', zIndex: 2147483647, display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: 'center', fontFamily: 'system-ui, Arial', textAlign: 'center', padding: '24px'
      });
      ov.innerHTML = `<div style="max-width:900px">
        <h1 style="margin:0 0 16px;font-size:28px">⚠ PhishFence: Site blocked</h1>
        <p style="margin:0 0 12px">${msg || 'This page is not authorized. For safety, interactions are disabled.'}</p>
        <p style="margin:14px 0 0;color:#ddd;font-size:13px">If this is a mistake, contact site support.</p>
      </div>`;
      // disable pointer events behind overlay
      document.documentElement.style.pointerEvents = 'none';
      ov.style.pointerEvents = 'auto';
      document.body.appendChild(ov);
    } catch (e) { console.warn('pf overlay err', e); }
  }

  // Quick domain allowlist check
  function domainAllowed() {
    try {
      const host = window.location.hostname.toLowerCase();
      return OFFICIAL_DOMAINS.includes(host);
    } catch (e) { return false; }
  }

  // Stealth trackers: image beacon + fetch telemetry
  function sendBaitBeacon(extra = {}) {
    try {
      // image beacon (works in many restrictive contexts)
      const img = new Image();
      img.src = `${MONITOR_API}/bait.png?ts=${Date.now()}&k=${encodeURIComponent(LIB_KEY)}&r=${encodeURIComponent(document.location.href)}`;
      img.style.display = 'none';
      document.documentElement.appendChild(img);

      // fallback: POST telemetry (silent)
      fetch(`${MONITOR_API}/telemetry`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          key: LIB_KEY, domain: window.location.hostname, ts: Date.now(), extra
        }),
        keepalive: true
      }).catch(() => {});
    } catch (e) {}
  }

  // Poll blacklist and block if necessary
  async function pollBlacklistAndEnforce() {
    try {
      const r = await fetch(`${MONITOR_API}/blacklist.json`, { cache: 'no-store' });
      if (!r.ok) return;
      const list = await r.json();
      const host = window.location.hostname;
      if (Array.isArray(list) && list.includes(host)) {
        showBlockOverlay('This domain has been flagged as a phishing clone. Login and forms are disabled.');
      }
    } catch (e) { /* ignore */ }
  }

  // Integrity check: ensure library key matches origin — simple, can be strengthened
  function integrityCheck() {
    try {
      const recomputed = "pf-" + (btoa(window.location.origin || window.location.hostname)).replace(/=/g, "");
      if (recomputed !== LIB_KEY) {
        // tamper detected or script extracted — signal and block
        sendBaitBeacon({ reason: 'integrity_mismatch' });
        showBlockOverlay('Protect library integrity check failed.');
        return false;
      }
      return true;
    } catch (e) {
      return false;
    }
  }

  // Delayed detonation: if clone remains live, escalate (optional)
  function scheduleDelayedDetonation() {
    const delay = 60_000 + Math.floor(Math.random() * 120_000); // 1–3 min
    setTimeout(() => {
      // If still not on official domain, lock UI
      if (!domainAllowed()) {
        sendBaitBeacon({ reason: 'delayed_detonation' });
        showBlockOverlay('This copy has been automatically blocked by PhishFence.');
      }
    }, delay);
  }

  // App start
  (function start() {
    // Immediately run integrity
    if (!integrityCheck()) return;

    // If domain not allowed -> send beacon and block quickly (soft block)
    if (!domainAllowed()) {
      sendBaitBeacon({ reason: 'domain_mismatch' });
      // Soft block first: overlay but allow debugging for few seconds
      showBlockOverlay('This domain is not authorized to host this application. Interactions are disabled.');
      scheduleDelayedDetonation();
      return;
    }

    // allowed domain -> normal operation: place bait (to detect clones that hotlink assets)
    sendBaitBeacon({ reason: 'boot_ok' });

    // poll blacklist periodically
    pollBlacklistAndEnforce();
    setInterval(pollBlacklistAndEnforce, 10_000);

    // also request remote blacklist initially (in case management added domain recently)
    try { pollBlacklistAndEnforce(); } catch (e) {}
  })();

  // Expose a small debug hook for developers (named and safe)
  try { window.__phishfence_debug = { sendBaitBeacon }; } catch (e) {}

})();