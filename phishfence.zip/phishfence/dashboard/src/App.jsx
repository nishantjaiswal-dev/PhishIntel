import React, { useEffect, useState } from "react";
import { io } from "socket.io-client";

const SOCKET_URL = "http://localhost:5000";
const API_URL = "http://localhost:5000";

export default function App() {
  const [detections, setDetections] = useState([]);
  const [blacklist, setBlacklist] = useState([]);

  useEffect(() => {
    // fetch initial detections
    fetch(`${API_URL}/detections`).then(r => r.json()).then(setDetections);

    // socket
    const socket = io(SOCKET_URL);
    socket.on('new-detection', (d) => {
      setDetections(prev => [d, ...prev].slice(0, 200));
    });
    socket.on('blacklist-updated', (list) => {
      setBlacklist(list);
    });

    // fetch blacklist
    fetch(`${API_URL}/blacklist.json`).then(r => r.json()).then(setBlacklist);

    return () => socket.disconnect();
  }, []);

  const doBlacklist = async (domain) => {
    await fetch(`${API_URL}/blacklist`, {
      method: 'POST', headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ domain })
    });
    const r = await fetch(`${API_URL}/blacklist.json`);
    const list = await r.json();
    setBlacklist(list);
  };

  return (
    <div className="dash">
      <header>
        <h1>PhishFence Dashboard</h1>
        <p>Real-time clone detections</p>
      </header>

      <section className="panel">
        <h2>Detections</h2>
        <table>
          <thead>
            <tr><th>Time</th><th>Referer</th><th>IP</th><th>UA</th><th>Action</th></tr>
          </thead>
          <tbody>
            {detections.map(d => (
              <tr key={d.id}>
                <td>{new Date(d.time).toLocaleString()}</td>
                <td style={{maxWidth:300,overflow:'hidden',textOverflow:'ellipsis'}}>{d.referer}</td>
                <td>{d.ip}</td>
                <td style={{maxWidth:300,overflow:'hidden',textOverflow:'ellipsis'}}>{d.ua}</td>
                <td><button onClick={() => doBlacklist(extractHost(d.referer) || d.referer)}>Blacklist</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      <aside className="panel">
        <h3>Current Blacklist</h3>
        <ul>
          {blacklist.map((b, i) => <li key={i}>{b}</li>)}
        </ul>
      </aside>
    </div>
  );
}

function extractHost(ref) {
  try {
    if(!ref) return null;
    const url = new URL(ref);
    return url.hostname;
  } catch(e){ return null; }
}