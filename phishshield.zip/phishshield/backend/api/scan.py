from fastapi import APIRouter
from fastapi import HTTPException

from schemas.scan_schema import (
    URLRequest
)

from analyzers.validator import (
    validate_url
)

from model.predictor import (
    predict_url
)

from analyzers.url_features import (
    analyze_url
)

from analyzers.ssl_checker import (
    check_ssl
)

from analyzers.whois_checker import (
    check_domain_age
)

from analyzers.redirect_checker import (
    check_redirects
)

from analyzers.content_checker import (
    scan_content
)

from analyzers.shortened_url import (
    check_shortened_url
)

from analyzers.brand_impersonation import (
    check_brand_impersonation
)

from analyzers.typosquatting import (
    detect_typosquatting
)

from analyzers.risk_indicators import (
    risk_indicators
)

from intelligence.openphish import (
    check_openphish
)

from intelligence.phishtank import (
    check_phishtank
)

from scoring.risk_engine import (
    calculate_risk
)

from reporting.explanation_engine import (
    generate_explanation
)

from reporting.recommendation_engine import (
    generate_recommendations
)

router = APIRouter()
@router.post("/scan")
def scan_url(request: URLRequest):

    url = request.url

    if not validate_url(url):

        raise HTTPException(
            status_code=400,
            detail="Invalid URL"
        )

    prediction = predict_url(url)

    url_features = analyze_url(url)

    ssl_data = check_ssl(url)

    whois_data = check_domain_age(url)

    redirect_data = check_redirects(url)

    content_data = scan_content(url)

    openphish_data = check_openphish(url)

    phishtank_data = check_phishtank(url)

    shortened_data = check_shortened_url(url)

    brand_data = check_brand_impersonation(url)

    typo_data = detect_typosquatting(url)

    indicator_data = risk_indicators(url)

    risk = calculate_risk(
        prediction,
        url_features,
        ssl_data,
        whois_data,
        redirect_data,
        content_data,
        openphish_data,
        phishtank_data,
        shortened_data,
        brand_data,
        typo_data,
        indicator_data
    )

    reasons = generate_explanation(
        prediction,
        ssl_data,
        whois_data,
        redirect_data,
        content_data,
        openphish_data,
        phishtank_data,
        shortened_data,
        brand_data,
        typo_data,
        indicator_data
    )

    recommendations = (
        generate_recommendations(
            risk["risk_score"]
        )
    )

    return {

        "url": url,

        "ai_prediction": prediction,

        "url_features": url_features,

        "ssl": ssl_data,

        "whois": whois_data,

        "redirects": redirect_data,

        "content": content_data,

        "openphish": openphish_data,

        "phishtank": phishtank_data,

        "shortened_url": shortened_data,

        "brand_analysis": brand_data,

        "typosquatting": typo_data,

        "risk_indicators": indicator_data,

        "risk": risk,

        "reasons": reasons,

        "recommendations":
            recommendations
    }